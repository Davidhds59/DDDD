

<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

$file = 'peliculas.json';

// Validar método de solicitud
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Método no permitido']);
    exit;
}

// Obtener datos JSON del cuerpo de la solicitud
$input = json_decode(file_get_contents('php://input'), true);

if (json_last_error() !== JSON_ERROR_NONE) {
    http_response_code(400);
    echo json_encode(['error' => 'Datos JSON inválidos']);
    exit;
}

// Leer datos existentes
$data = [];
if (file_exists($file)) {
    $content = file_get_contents($file);
    $data = json_decode($content, true) ?: [];
    
    // Verificar integridad del JSON
    if (json_last_error() !== JSON_ERROR_NONE) {
        $data = [];
    }
}

// Procesar operación
try {
    if (isset($input['eliminar'])) {
        // Eliminar película
        $data = array_values(array_filter($data, function($p) use ($input) {
            return $p['id'] != $input['eliminar'];
        }));
    } else {
        // Actualizar o agregar película
        $encontrado = false;
        foreach ($data as &$p) {
            if ($p['id'] == $input['id']) {
                $p = $input;
                $encontrado = true;
                break;
            }
        }
        if (!$encontrado) {
            $data[] = $input;
        }
    }
    
    // Guardar datos con bloqueo de archivo para evitar corrupción
    $fp = fopen($file, 'w');
    if (flock($fp, LOCK_EX)) {
        fwrite($fp, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        flock($fp, LOCK_UN);
    }
    fclose($fp);
    
    echo json_encode(['success' => true]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Error al procesar la solicitud']);
}
?>